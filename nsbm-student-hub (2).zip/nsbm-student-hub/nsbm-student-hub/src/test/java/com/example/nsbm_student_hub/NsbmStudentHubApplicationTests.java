package com.example.nsbm_student_hub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NsbmStudentHubApplicationTests {

	@Test
	void contextLoads() {
	}

}
